import psycopg2
import argparse

class PosgreSQLConnection():

    def __init__(self, address, username, password, port, database):
        self.address = address
        self.username = username
        self.password = password
        #self.database = database
        self.database = "postgres"
        if (port == ""):
            port = "5432"
        self.port = port

    def logon(self):
        conn = psycopg2.connect(
            host = self.address,
            user = self.username,
            password= self.password,
            port=self.port, 
            database=self.database)            
        with conn.cursor() as cursor:
            cursor.execute("select version ();")
            #print("Login Exitoso")
            record = cursor.fetchone()
            #print("Estas conectado en - ", record, "\n")
            print(record)
        conn.close()

    def change(self,newpass):
        conn = psycopg2.connect(
            host=self.address,
            user=self.username,
            password=self.password,            
            port=self.port,            
            database=self.database)
        with conn.cursor() as cursor:
            cursor.execute("ALTER USER " + self.username + " WITH PASSWORD " + "'" + str(newpass) + "'" + ";")
            conn.commit()
            print("Cambio de password completo")
            #print ("El resultado es - ", record, "\n")
            conn.close()

    def recon(self, username, newpass, logonusername, logonpassword):
        conn = psycopg2.connect(
            host=self.address,
            user=logonusername,
            password=logonpassword,
            port=self.port,
            database=self.database)
        with conn.cursor() as cursor:
            cursor.execute("ALTER USER " + username + " WITH PASSWORD " + "'" + str(newpass) + "'" + ";")
            conn.commit()
            #cursor.execute("ALTER USER "+"'"+username+"'"+"'"+"@"+"'"+"'"+ "%"+"'"+" IDENTIFIED BY "+"'"+newpass+"'"+";")
            print("Password Recuperado")
            conn.close()


def Main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--address", required=True, help="Address/Hostname")
    parser.add_argument("--username", required=False, help="Username")
    parser.add_argument("--password", required=False, help="Password")
    parser.add_argument("--port", required=False, help="Port")
    parser.add_argument("--logonusername", required=False, help="Logon Username")
    parser.add_argument("--logonpassword", required=False, help="Logon Password")
    parser.add_argument("--newpassword", required=False, help="New Password")
    parser.add_argument("--database", required=False, help="Database")
    parser.add_argument("--action", required=False, help="verifylogon/changepass/reconpass")
    args = parser.parse_args()

    inputaction = input("Action to do:").strip()

    # Password Logon or Password Verify
    if (inputaction in "verifylogon"):
        mydb = PosgreSQLConnection(str(args.address), str(args.username), str(args.password), int(args.port), str(args.database))
        mydb.logon()
    elif (inputaction in "changepass"):
        mydb = PosgreSQLConnection(str(args.address), str(args.username), str(args.password), int(args.port), str(args.database))
        newpassword = input("Ingrese Nuevo Pass:")
        mydb.change(newpassword)
    elif (inputaction in "reconpass"):
        mydb = PosgreSQLConnection(str(args.address), str(args.logonusername), str(args.logonpassword), int(args.port), str(args.database))
        newpassword = input("Ingrese Nuevo Pass:")
        mydb.recon(args.username,newpassword, args.logonusername, args.logonpassword)

if __name__ == "__main__":
    Main()